import React, { useEffect, useMemo, useState } from "react";

const todayISO = () => new Date().toISOString().slice(0, 10);
const nowHM = () => {
  const d = new Date();
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${h}:${m}`;
};

const STORAGE_KEY = "twinsDailyLog.v1";

export default function App() {
  const [entries, setEntries] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [dateFilter, setDateFilter] = useState(todayISO());
  const [form, setForm] = useState({
    date: todayISO(),
    time: nowHM(),
    twin: "A",
    feedType: "",
    feedOz: "",
    feedMin: "",
    pumpOz: "",
    pumpMin: "",
    diaper: "",
    sleepStart: "",
    sleepEnd: "",
    notes: "",
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  }, [entries]);

  const dayEntries = useMemo(
    () =>
      entries
        .filter((e) => e.date === dateFilter)
        .sort((a, b) => (a.time || "").localeCompare(b.time || "")),
    [entries, dateFilter]
  );

  const resetForm = () =>
    setForm({
      ...form,
      time: nowHM(),
      feedType: "",
      feedOz: "",
      feedMin: "",
      pumpOz: "",
      pumpMin: "",
      diaper: "",
      sleepStart: "",
      sleepEnd: "",
      notes: "",
    });

  const addEntry = () => {
    const clean = {
      id: crypto.randomUUID(),
      ...form,
      feedOz: form.feedOz === "" ? null : Number(form.feedOz),
      feedMin: form.feedMin === "" ? null : Number(form.feedMin),
      pumpOz: form.pumpOz === "" ? null : Number(form.pumpOz),
      pumpMin: form.pumpMin === "" ? null : Number(form.pumpMin),
    };
    setEntries((prev) => [...prev, clean]);
    resetForm();
  };

  const duplicateForOtherTwin = () => {
    const t = form.twin === "A" ? "B" : "A";
    setForm({ ...form, twin: t });
  };

  const exportCSV = () => {
    const header = [
      "Date","Time","Twin","FeedType","FeedOz","FeedMin","PumpOz","PumpMin","Diaper(W/S/B)","SleepStart","SleepEnd","Notes",
    ];
    const rows = dayEntries.map((e) => [
      e.date, e.time || "", e.twin, e.feedType || "", e.feedOz ?? "", e.feedMin ?? "",
      e.pumpOz ?? "", e.pumpMin ?? "", e.diaper || "", e.sleepStart || "", e.sleepEnd || "",
      (e.notes || "").replace(/\n/g, " ")
    ]);
    const csv = [header, ...rows].map(r =>
      r.map(cell => (typeof cell === "string" && (cell.includes(",") || cell.includes('"')))
        ? '"' + cell.replaceAll('"','""') + '"'
        : cell
      ).join(",")
    ).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `twins-log-${dateFilter}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const clearDay = () => {
    if (!confirm(`Clear all entries for ${dateFilter}?`)) return;
    setEntries(entries.filter((e) => e.date !== dateFilter));
  };

  const Field = ({ label, children }) => (
    <div className="flex flex-col gap-1">
      <span className="text-xs text-gray-500">{label}</span>
      {children}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <div className="max-w-5xl mx-auto p-4 md:p-8">
        <header className="mb-4 flex flex-col md:flex-row md:items-end gap-3 md:gap-6">
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl font-semibold">Twins Daily Log</h1>
            <p className="text-sm text-gray-600">
              Quick, offline-friendly tracker for Twin A & Twin B — feeds, diapers, sleep, notes.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="date"
              className="border rounded-lg px-3 py-2 text-sm"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
            />
            <button onClick={() => window.print()} className="px-3 py-2 rounded-lg border text-sm hover:bg-gray-100">Print</button>
            <button onClick={exportCSV} className="px-3 py-2 rounded-lg border text-sm hover:bg-gray-100">Export CSV</button>
            <button onClick={clearDay} className="px-3 py-2 rounded-lg border text-sm hover:bg-red-50">Clear Day</button>
          </div>
        </header>

        {/* Entry Form */}
        <section className="bg-white rounded-2xl shadow-sm border p-4 md:p-6 mb-6">
          <h2 className="text-lg font-medium mb-3">Add Entry</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Field label="Date">
              <input type="date" value={form.date} onChange={(e)=>setForm({...form, date: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full" />
            </Field>
            <Field label="Time">
              <input type="time" value={form.time} onChange={(e)=>setForm({...form, time: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full" />
            </Field>
            <Field label="Twin">
              <div className="flex gap-2">
                {(["A","B"]).map(t => (
                  <button key={t} onClick={()=>setForm({...form, twin: t})} className={`px-3 py-2 rounded-lg border text-sm w-full ${form.twin===t? 'bg-gray-900 text-white':'hover:bg-gray-100'}`}>{t}</button>
                ))}
              </div>
            </Field>
            <Field label="Diaper (W/S/B)">
              <div className="flex gap-2">
                {(["","W","S","B"]).map(d => (
                  <button key={d||"None"} onClick={()=>setForm({...form, diaper: d})} className={`px-3 py-2 rounded-lg border text-sm w-full ${form.diaper===d? 'bg-gray-900 text-white':'hover:bg-gray-100'}`}>{d||"—"}</button>
                ))}
              </div>
            </Field>
            <Field label="Feed Type">
              <select value={form.feedType} onChange={(e)=>setForm({...form, feedType: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full">
                <option value="">—</option>
                <option>breast</option>
                <option>formula</option>
                <option>pumped</option>
                <option>other</option>
              </select>
            </Field>
            <Field label="Feed Oz">
              <input type="number" min="0" step="0.5" value={form.feedOz} onChange={(e)=>setForm({...form, feedOz: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Feed Minutes">
              <input type="number" min="0" step="1" value={form.feedMin} onChange={(e)=>setForm({...form, feedMin: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Pump Oz (mom)">
              <input type="number" min="0" step="0.5" value={form.pumpOz} onChange={(e)=>setForm({...form, pumpOz: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Pump Minutes (mom)">
              <input type="number" min="0" step="1" value={form.pumpMin} onChange={(e)=>setForm({...form, pumpMin: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Sleep (start)">
              <input type="time" value={form.sleepStart} onChange={(e)=>setForm({...form, sleepStart: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Sleep (end)">
              <input type="time" value={form.sleepEnd} onChange={(e)=>setForm({...form, sleepEnd: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full"/>
            </Field>
            <Field label="Notes">
              <textarea rows={2} value={form.notes} onChange={(e)=>setForm({...form, notes: e.target.value})} className="border rounded-lg px-3 py-2 text-sm w-full" placeholder="Reflux, meds, soothing, temp, etc."/>
            </Field>
          </div>
          <div className="mt-4 flex flex-col md:flex-row gap-2">
            <button onClick={addEntry} className="px-4 py-2 rounded-xl bg-gray-900 text-white text-sm">Add Entry</button>
            <button onClick={duplicateForOtherTwin} className="px-4 py-2 rounded-xl border text-sm">Duplicate for other twin</button>
          </div>
        </section>

        {/* Day View */}
        <section className="bg-white rounded-2xl shadow-sm border p-4 md:p-6">
          <h2 className="text-lg font-medium mb-3">Entries for {dateFilter}</h2>
          {dayEntries.length === 0 ? (
            <p className="text-sm text-gray-500">No entries yet. Use the form above to add your first entry.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead>
                  <tr className="text-left text-gray-500">
                    {["Time","Twin","Feed (type/oz/min)","Pump (oz/min)","Diaper","Sleep (start–end)","Notes"].map(h => <th key={h} className="py-2 px-2 border-b">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {dayEntries.map((e) => (
                    <tr key={e.id} className="border-b last:border-b-0">
                      <td className="py-2 px-2 whitespace-nowrap">{e.time || ""}</td>
                      <td className="py-2 px-2">{e.twin}</td>
                      <td className="py-2 px-2">
                        {[e.feedType||null, e.feedOz!=null? `${e.feedOz} oz` : null, e.feedMin!=null? `${e.feedMin} min` : null].filter(Boolean).join(" · ")}
                      </td>
                      <td className="py-2 px-2">
                        {[e.pumpOz!=null? `${e.pumpOz} oz` : null, e.pumpMin!=null? `${e.pumpMin} min` : null].filter(Boolean).join(" · ")}
                      </td>
                      <td className="py-2 px-2">{e.diaper || ""}</td>
                      <td className="py-2 px-2">{(e.sleepStart||"") + (e.sleepEnd? ` – ${e.sleepEnd}`: "")}</td>
                      <td className="py-2 px-2 max-w-[28rem]">{e.notes}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <footer className="text-xs text-gray-500 mt-6">
          Local-only prototype. Data stays in your browser (LocalStorage). Export CSV to back up. — Zeal
        </footer>
      </div>
    </div>
  );
}
